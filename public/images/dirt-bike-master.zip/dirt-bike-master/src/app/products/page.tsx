import ProductsList from '@/features/products/ProductList';

export default function Page() {
  return <ProductsList />;
}
